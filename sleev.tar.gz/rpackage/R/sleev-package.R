## usethis namespace: start
#' sleev: combining functions from logreg2ph and TwoPhaseReg
#'
#'
#' @name sleev
#'
#' @importFrom Rcpp sourceCpp
#' @useDynLib sleev, .registration=TRUE
#' @noRd
## usethis namespace: end
NULL
